#include <stdio.h>
#include <stdlib.h>

void recAdMat(int dims[], int n, int **m, int **s);
void printTable(int n, int **table);
void printParentheses(int **s, int i, int j);

int main() {
    int n;
    printf("Enter the number of matrices: ");
    scanf("%d", &n);

    int *dims = (int *)malloc((n + 1) * sizeof(int));
    printf("Enter the dimensions (size %d): ", n + 1);
    for (int i = 0; i <= n; i++) {
        scanf("%d", &dims[i]);
    }

    int **m = (int **)malloc((n + 1) * sizeof(int *));
    int **s = (int **)malloc((n + 1) * sizeof(int *));
    for (int i = 0; i <= n; i++) {
        m[i] = (int *)malloc((n + 1) * sizeof(int));
        s[i] = (int *)malloc((n + 1) * sizeof(int));
    }

    recAdMat(dims, n + 1, m, s);
    printTable(n + 1, m);
    printTable(n + 1, s);

    printf("\nMinimum number of scalar multiplications required: %d\n", m[1][n]);
    printf("\nOptimal Parenthesization: ");
    printParentheses(s, 1, n);
    printf("\n");

    for (int i = 0; i <= n; i++) {
        free(m[i]);
        free(s[i]);
    }
    free(m);
    free(s);
    free(dims);

    return 0;
}

void recAdMat(int dims[], int n, int **m, int **s) {
    for (int i = 1; i < n; i++) {
        m[i][i] = 0;
    }

    for (int l = 2; l < n; l++) {
        for (int i = 1; i <= n - l; i++) {
            int j = i + l - 1;
            m[i][j] = m[i][i] + m[i + 1][j] + dims[i - 1] * dims[i] * dims[j];
            s[i][j] = i; // Default partition
            for (int k = i; k < j; k++) {
                int cost = m[i][k] + m[k + 1][j] + dims[i - 1] * dims[k] * dims[j];
                if (cost < m[i][j]) {
                    m[i][j] = cost;
                    s[i][j] = k;
                }
            }
        }
    }
}

void printTable(int n, int **table) {
    printf("\nTable:\n\n");
    printf("      ");
    for (int j = 1; j < n; j++) {
        printf("   A%d   ", j);
    }
    printf("\n");

    for (int i = n - 1; i >= 1; i--) {
        printf(" A%d  ", i);
        for (int j = 1; j < n; j++) {
            if (i == j) {
                printf("   0   ");
            }
            if (i > j) {
                printf("   %d   ", table[j][i]);
            } else {
                printf("        ", table[i][j]);
            }
        }
        printf("\n");
    }
}

void printParentheses(int **s, int i, int j) {
    if (i == j) {
        printf("A%d", i);
        return;
    }
    printf("(");
    printParentheses(s, i, s[i][j]);
    printParentheses(s, s[i][j] + 1, j);
    printf(")");
}

/* Example:
Input:
Enter the number of matrices: 4
Enter the dimensions (size 5): 50 40 10 50 20

Output:
Table:

      A1      A2      A3      A4   
 A4  40000    18000    10000       0
 A3  45000    20000       0
 A2  20000       0
 A1      0

Parenthesization Table:

      A1      A2      A3      A4   
 A4      1        2        3        
 A3      2        2        
 A2      1        
 A1        

Minimum number of scalar multiplications required: 40000

Optimal Parenthesization: ((A1(A2A3))A4)
*/
