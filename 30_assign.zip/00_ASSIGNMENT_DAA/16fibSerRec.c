#include <stdio.h>

int fibRec(int n);
void fibSeriesRec(int n);

int main() {
    int n;
    printf("Enter the number of terms: ");
    scanf("%d", &n);

    fibSeriesRec(n);
    return 0;
}

int fibRec(int n) {
    if (n <= 1)
        return n;
    return fibRec(n - 1) + fibRec(n - 2);
}

void fibSeriesRec(int n) {
    printf("Fibonacci series: ");
    for (int i = 0; i < n; i++) {
        printf("%d ", fibRec(i));
    }
    printf("\n");
}

/* Example:
Input:
Enter the number of terms: 5
Output:
Fibonacci series: 0 1 1 2 3
*/