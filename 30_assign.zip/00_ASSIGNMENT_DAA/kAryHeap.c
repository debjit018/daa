#include <stdio.h>
#include <stdlib.h>
#include <math.h>

// Function prototypes
void insert(int *heap, int *size, int k, int value);
void maxHeapify(int *heap, int size, int k, int index);
void printHeap(int *heap, int size);

int main() {
    int k, n, value;
    printf("Enter the value of k (number of children per node): ");
    scanf("%d", &k);

    printf("Enter the number of elements to insert: ");
    scanf("%d", &n);

    // Dynamically allocate memory for the heap
    int *heap = (int *)calloc(n, sizeof(int));
    int size = 0;

    // Insert elements into the heap
    printf("Enter %d elements to insert into the k-ary max-heap:\n", n);
    for (int i = 0; i < n; i++) {
        scanf("%d", &value);
        insert(heap, &size, k, value);
    }

    // Print the max-heap
    printf("The k-ary max-heap is:\n");
    printHeap(heap, size);

    // Free allocated memory
    free(heap);
    return 0;
}

// Function to insert a value into the k-ary max-heap
void insert(int *heap, int *size, int k, int value) {
    heap[*size] = value; // Insert at the end
    int index = *size;
    (*size)++;

    // Fix the max-heap property
    int parent = (index - 1) / k;
    while (index > 0 && heap[index] > heap[parent]) {
        int temp = heap[index];
        heap[index] = heap[parent];
        heap[parent] = temp;

        index = parent;
        parent = (index - 1) / k;
    }
}

// Function to heapify a k-ary max-heap at a specific index
void maxHeapify(int *heap, int size, int k, int index) {
    int largest = index;

    // Check all k children
    for (int i = 1; i <= k; i++) {
        int child = k * index + i;
        if (child < size && heap[child] > heap[largest]) {
            largest = child;
        }
    }

    // If largest is not the current index, swap and heapify
    if (largest != index) {
        int temp = heap[index];
        heap[index] = heap[largest];
        heap[largest] = temp;

        maxHeapify(heap, size, k, largest);
    }
}

// Function to print the k-ary max-heap
void printHeap(int *heap, int size) {
    for (int i = 0; i < size; i++) {
        printf("%d ", heap[i]);
    }
    printf("\n");
}