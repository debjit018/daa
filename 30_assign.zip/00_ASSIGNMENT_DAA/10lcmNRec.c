#include <stdio.h>

int recGcd(int a, int b);
int recLcm(int a, int b);
int lcma(int arr[], int n, int idx);

int main() {
    int n;
    printf("Enter the number of elements: ");
    scanf("%d", &n);

    int arr[n];
    printf("Enter %d elements: ", n);
    for (int i = 0; i < n; i++) {
        scanf("%d", &arr[i]);
    }

    int lcm = lcma(arr, n, 0);
    printf("LCM of the array: %d\n", lcm);
    return 0;
}

int recGcd(int a, int b) {
    if (b == 0) {
        return a;
    }
    return recGcd(b, a % b);
}

int recLcm(int a, int b) {
    return (a * b) / recGcd(a, b);
}

int lcma(int arr[], int n, int idx) {
    if (idx == n - 1) {
        return arr[idx];
    }
    int nxLcm = lcma(arr, n, idx + 1);
    return recLcm(arr[idx], nxLcm);
}

/* Example:
Input:
Enter the number of elements: 3
Enter 3 elements: 4 5 6
Output:
LCM of the array: 60
*/