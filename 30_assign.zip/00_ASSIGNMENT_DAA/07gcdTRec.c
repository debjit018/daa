#include <stdio.h>

int recGcd(int a, int b);

int main() {
    int a, b;
    printf("Enter two numbers: ");
    scanf("%d %d", &a, &b);

    int gcd = recGcd(a, b);
    printf("GCD of %d and %d: %d\n", a, b, gcd);
    return 0;
}

int recGcd(int a, int b) {
    if (b == 0) {
        return a;
    }
    return recGcd(b, a % b);
}

/* Example:
Input:
Enter two numbers: 48 18
Output:
GCD of 48 and 18: 6
*/