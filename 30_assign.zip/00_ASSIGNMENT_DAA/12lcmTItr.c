#include <stdio.h>

int gcdIter(int a, int b);
int lcmIter(int a, int b);

int main() {
    int a, b;
    printf("Enter two numbers: ");
    scanf("%d %d", &a, &b);

    printf("LCM: %d\n", lcmIter(a, b));
    return 0;
}

int gcdIter(int a, int b) {
    while (b != 0) {
        int temp = b;
        b = a % b;
        a = temp;
    }
    return a;
}

int lcmIter(int a, int b) {
    return (a * b) / gcdIter(a, b);
}

/* Example:
Input:
Enter two numbers: 8 12
Output:
LCM: 24
*/