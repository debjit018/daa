#include <stdio.h>

int recGcd(int a, int b);
int gcda(int arr[], int n, int idx);

int main() {
    int n;
    printf("Enter the number of elements: ");
    scanf("%d", &n);

    int arr[n];
    printf("Enter %d elements: ", n);
    for (int i = 0; i < n; i++) {
        scanf("%d", &arr[i]);
    }

    int gcd = gcda(arr, n, 0);
    printf("GCD of the array: %d\n", gcd);
    return 0;
}

int recGcd(int a, int b) {
    if (b == 0) {
        return a;
    }
    return recGcd(b, a % b);
}

int gcda(int arr[], int n, int idx) {
    if (idx == n - 1) {
        return arr[idx];
    }
    return recGcd(arr[idx], gcda(arr, n, idx + 1));
}

/* Example:
Input:
Enter the number of elements: 4
Enter 4 elements: 48 72 96 120
Output:
GCD of the array: 24
*/