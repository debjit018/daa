#include <stdio.h>

int gcdIter(int a, int b);
int lcmIter(int a, int b);
int lcmNIter(int arr[], int n);

int main() {
    int n;
    printf("Enter number of elements: ");
    scanf("%d", &n);

    int arr[n];
    printf("Enter %d elements: ", n);
    for (int i = 0; i < n; i++) {
        scanf("%d", &arr[i]);
    }

    printf("LCM: %d\n", lcmNIter(arr, n));
    return 0;
}

int gcdIter(int a, int b) {
    while (b != 0) {
        int temp = b;
        b = a % b;
        a = temp;
    }
    return a;
}

int lcmIter(int a, int b) {
    return (a * b) / gcdIter(a, b);
}

int lcmNIter(int arr[], int n) {
    int result = arr[0];
    for (int i = 1; i < n; i++) {
        result = lcmIter(result, arr[i]);
    }
    return result;
}

/* Example:
Input:
Enter number of elements: 3
Enter 3 elements: 3 6 9
Output:
LCM: 18
*/