#include <stdio.h>

int recGcd(int a, int b);
int recLcm(int a, int b);

int main() {
    int a, b;
    printf("Enter two numbers: ");
    scanf("%d %d", &a, &b);

    int lcm = recLcm(a, b);
    printf("LCM of %d and %d: %d\n", a, b, lcm);
    return 0;
}

int recGcd(int a, int b) {
    if (b == 0) {
        return a;
    }
    return recGcd(b, a % b);
}

int recLcm(int a, int b) {
    return (a * b) / recGcd(a, b);
}

/* Example:
Input:
Enter two numbers: 12 15
Output:
LCM of 12 and 15: 60
*/