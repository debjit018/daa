#include <stdio.h>

void fibSeries(int n);

int main() {
    int n;
    printf("Enter the number of terms: ");
    scanf("%d", &n);

    fibSeries(n);
    return 0;
}

void fibSeries(int n) {
    int a = 0, b = 1, c;
    printf("Fibonacci series: ");
    for (int i = 0; i < n; i++) {
        printf("%d ", a);
        c = a + b;
        a = b;
        b = c;
    }
    printf("\n");
}

/* Example:
Input:
Enter the number of terms: 6
Output:
Fibonacci series: 0 1 1 2 3 5
*/