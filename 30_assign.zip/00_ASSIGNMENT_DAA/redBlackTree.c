#include <stdio.h>
#include <stdlib.h>

#define RED 0
#define BLACK 1

struct Node {
    int data;
    int color;
    struct Node *left, *right, *parent;
};

typedef struct Node Node;

Node *createNode(int data);
Node *rotateLeft(Node *root, Node *x);
Node *rotateRight(Node *root, Node *y);
Node *fixViolation(Node *root, Node *pt);
Node *insertNode(Node *root, Node *pt);
Node *insert(Node *root, int data);
Node *findMin(Node *root);
Node *deleteFixup(Node *root, Node *x);
Node *deleteNode(Node *root, int data);
void inorder(Node *root);
void preorder(Node *root);
void postorder(Node *root);

int main() {
    Node *root = NULL;
    int choice, value;

    do {
        printf("\nMenu:\n");
        printf("1. Insert\n");
        printf("2. Delete\n");
        printf("3. Inorder Traversal\n");
        printf("4. Preorder Traversal\n");
        printf("5. Postorder Traversal\n");
        printf("6. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                printf("Enter value to insert: ");
                scanf("%d", &value);
                root = insert(root, value);
                break;
            case 2:
                printf("Enter value to delete: ");
                scanf("%d", &value);
                root = deleteNode(root, value);
                break;
            case 3:
                printf("Inorder Traversal: ");
                inorder(root);
                printf("\n");
                break;
            case 4:
                printf("Preorder Traversal: ");
                preorder(root);
                printf("\n");
                break;
            case 5:
                printf("Postorder Traversal: ");
                postorder(root);
                printf("\n");
                break;
            case 6:
                printf("Exiting program.\n");
                break;
            default:
                printf("Invalid choice. Try again.\n");
        }
    } while (choice != 6);

    return 0;
}

Node *createNode(int data) {
    Node *newNode = (Node *)calloc(1, sizeof(Node));
    newNode->data = data;
    newNode->color = RED; // New nodes are always red initially
    return newNode;
}

Node *rotateLeft(Node *root, Node *x) {
    Node *y = x->right;
    x->right = y->left;
    if (y->left) y->left->parent = x;
    y->parent = x->parent;
    if (!x->parent)
        root = y;
    else if (x == x->parent->left)
        x->parent->left = y;
    else
        x->parent->right = y;
    y->left = x;
    x->parent = y;
    return root;
}

Node *rotateRight(Node *root, Node *y) {
    Node *x = y->left;
    y->left = x->right;
    if (x->right) x->right->parent = y;
    x->parent = y->parent;
    if (!y->parent)
        root = x;
    else if (y == y->parent->left)
        y->parent->left = x;
    else
        y->parent->right = x;
    x->right = y;
    y->parent = x;
    return root;
}

Node *fixViolation(Node *root, Node *pt) {
    while (pt->parent && pt->parent->color == RED) {
        Node *parent = pt->parent;
        Node *grandparent = parent->parent;

        if (parent == grandparent->left) {
            Node *uncle = grandparent->right;

            if (uncle && uncle->color == RED) {
                grandparent->color = RED;
                parent->color = BLACK;
                uncle->color = BLACK;
                pt = grandparent;
            } else {
                if (pt == parent->right) {
                    root = rotateLeft(root, parent);
                    pt = parent;
                    parent = pt->parent;
                }
                root = rotateRight(root, grandparent);
                parent->color = BLACK;
                grandparent->color = RED;
                pt = parent;
            }
        } else {
            Node *uncle = grandparent->left;

            if (uncle && uncle->color == RED) {
                grandparent->color = RED;
                parent->color = BLACK;
                uncle->color = BLACK;
                pt = grandparent;
            } else {
                if (pt == parent->left) {
                    root = rotateRight(root, parent);
                    pt = parent;
                    parent = pt->parent;
                }
                root = rotateLeft(root, grandparent);
                parent->color = BLACK;
                grandparent->color = RED;
                pt = parent;
            }
        }
    }
    root->color = BLACK;
    return root;
}

Node *insertNode(Node *root, Node *pt) {
    if (!root) return pt;

    if (pt->data < root->data) {
        root->left = insertNode(root->left, pt);
        root->left->parent = root;
    } else if (pt->data > root->data) {
        root->right = insertNode(root->right, pt);
        root->right->parent = root;
    }
    return root;
}

Node *insert(Node *root, int data) {
    Node *pt = createNode(data);
    root = insertNode(root, pt);
    return fixViolation(root, pt);
}

Node *findMin(Node *root) {
    while (root->left) root = root->left;
    return root;
}

Node *deleteFixup(Node *root, Node *x) {
    while (x != root && (!x || x->color == BLACK)) {
        if (x == x->parent->left) {
            Node *sibling = x->parent->right;

            if (sibling && sibling->color == RED) {
                sibling->color = BLACK;
                x->parent->color = RED;
                root = rotateLeft(root, x->parent);
                sibling = x->parent->right;
            }

            if ((!sibling->left || sibling->left->color == BLACK) &&
                (!sibling->right || sibling->right->color == BLACK)) {
                sibling->color = RED;
                x = x->parent;
            } else {
                if (!sibling->right || sibling->right->color == BLACK) {
                    if (sibling->left) sibling->left->color = BLACK;
                    sibling->color = RED;
                    root = rotateRight(root, sibling);
                    sibling = x->parent->right;
                }
                sibling->color = x->parent->color;
                x->parent->color = BLACK;
                if (sibling->right) sibling->right->color = BLACK;
                root = rotateLeft(root, x->parent);
                x = root;
            }
        } else {
            Node *sibling = x->parent->left;

            if (sibling && sibling->color == RED) {
                sibling->color = BLACK;
                x->parent->color = RED;
                root = rotateRight(root, x->parent);
                sibling = x->parent->left;
            }

            if ((!sibling->right || sibling->right->color == BLACK) &&
                (!sibling->left || sibling->left->color == BLACK)) {
                sibling->color = RED;
                x = x->parent;
            } else {
                if (!sibling->left || sibling->left->color == BLACK) {
                    if (sibling->right) sibling->right->color = BLACK;
                    sibling->color = RED;
                    root = rotateLeft(root, sibling);
                    sibling = x->parent->left;
                }
                sibling->color = x->parent->color;
                x->parent->color = BLACK;
                if (sibling->left) sibling->left->color = BLACK;
                root = rotateRight(root, x->parent);
                x = root;
            }
        }
    }
    if (x) x->color = BLACK;
    return root;
}

Node *deleteNode(Node *root, int data) {
    if (!root) return root;

    if (data < root->data) {
        root->left = deleteNode(root->left, data);
    } else if (data > root->data) {
        root->right = deleteNode(root->right, data);
    } else {
        if (!root->left || !root->right) {
            Node *temp = root->left ? root->left : root->right;
            if (!temp) {
                temp = root;
                root = NULL;
            } else {
                *root = *temp;
            }
            free(temp);
        } else {
            Node *temp = findMin(root->right);
            root->data = temp->data;
            root->right = deleteNode(root->right, temp->data);
        }
    }
    if (!root) return root;

    return deleteFixup(root, root);
}

void inorder(Node *root) {
    if (root) {
        inorder(root->left);
        printf("%d ", root->data);
        inorder(root->right);
    }
}

void preorder(Node *root) {
    if (root) {
        printf("%d ", root->data);
        preorder(root->left);
        preorder(root->right);
    }
}

void postorder(Node *root) {
    if (root) {
        postorder(root->left);
        postorder(root->right);
        printf("%d ", root->data);
    }
}

/* Example:
Menu:
1. Insert
2. Delete
3. Inorder Traversal
4. Preorder Traversal
5. Postorder Traversal
6. Exit
Enter your choice: 1
Enter value to insert: 10
Enter your choice: 1
Enter value to insert: 20
Enter your choice: 3
Inorder Traversal: 10 20
*/