#include <stdio.h>

int gcdIter(int a, int b);
int gcdNIter(int arr[], int n);

int main() {
    int n;
    printf("Enter number of elements: ");
    scanf("%d", &n);

    int arr[n];
    printf("Enter %d elements: ", n);
    for (int i = 0; i < n; i++) {
        scanf("%d", &arr[i]);
    }

    printf("GCD: %d\n", gcdNIter(arr, n));
    return 0;
}

int gcdIter(int a, int b) {
    while (b != 0) {
        int temp = b;
        b = a % b;
        a = temp;
    }
    return a;
}

int gcdNIter(int arr[], int n) {
    int result = arr[0];
    for (int i = 1; i < n; i++) {
        result = gcdIter(result, arr[i]);
    }
    return result;
}

/* Example:
Input:
Enter number of elements: 4
Enter 4 elements: 16 32 48 64
Output:
GCD: 16
*/