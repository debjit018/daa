#include <stdio.h>
#include <stdlib.h>

void recAdMat(int dims[], int n, int **m);
void printTable(int n, int **table);

int main() {
    int n;
    printf("Enter the number of matrices: ");
    scanf("%d", &n);

    int *dims = (int *)malloc((n + 1) * sizeof(int));
    printf("Enter the dimensions (size %d): ", n + 1);
    for (int i = 0; i <= n; i++) {
        scanf("%d", &dims[i]);
    }

    int **m = (int **)malloc((n + 1) * sizeof(int *));
    for (int i = 0; i <= n; i++) {
        m[i] = (int *)malloc((n + 1) * sizeof(int));
    }

    recAdMat(dims, n + 1, m);
    printTable(n + 1, m);

    printf("\nMinimum number of scalar multiplications required: %d\n", m[1][n]);

    for (int i = 0; i <= n; i++) {
        free(m[i]);
    }
    free(m);
    free(dims);

    return 0;
}

void recAdMat(int dims[], int n, int **m) {
    for (int i = 1; i < n; i++) {
        m[i][i] = 0;
    }

    for (int l = 2; l < n; l++) {
        for (int i = 1; i <= n - l; i++) {
            int j = i + l - 1;
            m[i][j] = m[i][i] + m[i + 1][j] + dims[i - 1] * dims[i] * dims[j];
            for (int k = i; k < j; k++) {
                int cost = m[i][k] + m[k + 1][j] + dims[i - 1] * dims[k] * dims[j];
                if (cost < m[i][j]) {
                    m[i][j] = cost;
                }
            }
        }
    }
}

void printTable(int n, int **table) {
    printf("\nTable:\n\n");
    printf("      ");
    for (int j = 1; j < n; j++) {
        printf("   A%d   ", j);
    }
    printf("\n");

    for (int i = 1; i < n; i++) {
        printf(" A%d  ", i);
        for (int j = 1; j < n; j++) {
            if (i <= j) {
                printf("   %d   ", table[i][j]);
            } else {
                printf("         ");
            }
        }
        printf("\n");
    }
}