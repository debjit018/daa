#include <stdio.h>
#include <stdlib.h>

typedef struct Node {
    int data;
    struct Node *left, *right;
} Node;

Node* createNode(int data);
Node* insertNode(Node* root, int data);
void inorder(Node* root);
void preorder(Node* root);
void postorder(Node* root);

int main() {
    Node* root = NULL;
    int choice, val;

    printf("Binary Tree Traversal\n");
    printf("1. Insert Node\n");
    printf("2. Inorder Traversal\n");
    printf("3. Preorder Traversal\n");
    printf("4. Postorder Traversal\n");
    printf("5. Exit\n");

    while (1) {
        printf("\nEnter your choice: ");
        scanf("%d", &choice);
        switch (choice) {
            case 1:
                printf("Enter value to insert: ");
                scanf("%d", &val);
                root = insertNode(root, val);
                break;
            case 2:
                printf("Inorder Traversal: ");
                inorder(root);
                printf("\n");
                break;
            case 3:
                printf("Preorder Traversal: ");
                preorder(root);
                printf("\n");
                break;
            case 4:
                printf("Postorder Traversal: ");
                postorder(root);
                printf("\n");
                break;
            case 5:
                printf("Exiting...\n");
                return 0;
            default:
                printf("Invalid choice!\n");
        }
    }
    return 0;
}

Node* createNode(int data) {
    Node* newNode = (Node*)calloc(1, sizeof(Node));
    newNode->data = data;
    return newNode;
}

Node* insertNode(Node* root, int data) {
    if (root == NULL) {
        return createNode(data);
    }
    if (data < root->data) {
        root->left = insertNode(root->left, data);
    } else {
        root->right = insertNode(root->right, data);
    }
    return root;
}

void inorder(Node* root) {
    if (root) {
        inorder(root->left);
        printf("%d ", root->data);
        inorder(root->right);
    }
}

void preorder(Node* root) {
    if (root) {
        printf("%d ", root->data);
        preorder(root->left);
        preorder(root->right);
    }
}

void postorder(Node* root) {
    if (root) {
        postorder(root->left);
        postorder(root->right);
        printf("%d ", root->data);
    }
}

/* Example:
Input:
Binary Tree Traversal
1. Insert Node
2. Inorder Traversal
3. Preorder Traversal
4. Postorder Traversal
5. Exit

Enter your choice: 1
Enter value to insert: 10
Enter your choice: 1
Enter value to insert: 5
Enter your choice: 1
Enter value to insert: 15
Enter your choice: 2
Inorder Traversal: 5 10 15

Enter your choice: 3
Preorder Traversal: 10 5 15

Enter your choice: 4
Postorder Traversal: 5 15 10

Enter your choice: 5
Exiting...
*/