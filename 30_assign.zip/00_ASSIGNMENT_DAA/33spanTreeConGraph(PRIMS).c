#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

void primMST(int** graph, int v);

int main() {
    int v, e;
    printf("Enter the number of vertices: ");
    scanf("%d", &v);

    int** graph = (int**)malloc(v * sizeof(int*));
    for (int i = 0; i < v; i++) {
        graph[i] = (int*)calloc(v, sizeof(int));
    }

    printf("Enter the number of edges: ");
    scanf("%d", &e);

    printf("Enter the edges with weights (u v w format, 0-indexed):\n");
    for (int i = 0; i < e; i++) {
        int u, v, w;
        scanf("%d %d %d", &u, &v, &w);
        graph[u][v] = w;
        graph[v][u] = w;
    }

    printf("Edges in the Minimum Spanning Tree:\n");
    primMST(graph, v);

    for (int i = 0; i < v; i++) {
        free(graph[i]);
    }
    free(graph);

    return 0;
}

int findMinVertex(int* key, int* mstSet, int v) {
    int min = INT_MAX, minIndex;
    for (int i = 0; i < v; i++) {
        if (!mstSet[i] && key[i] < min) {
            min = key[i];
            minIndex = i;
        }
    }
    return minIndex;
}

void primMST(int** graph, int v) {
    int* parent = (int*)malloc(v * sizeof(int));
    int* key = (int*)malloc(v * sizeof(int));
    int* mstSet = (int*)calloc(v, sizeof(int));

    for (int i = 0; i < v; i++) {
        key[i] = INT_MAX;
        parent[i] = -1;
    }
    key[0] = 0;

    for (int count = 0; count < v - 1; count++) {
        int u = findMinVertex(key, mstSet, v);
        mstSet[u] = 1;

        for (int i = 0; i < v; i++) {
            if (graph[u][i] && !mstSet[i] && graph[u][i] < key[i]) {
                parent[i] = u;
                key[i] = graph[u][i];
            }
        }
    }

    for (int i = 1; i < v; i++) {
        printf("%d - %d\n", parent[i], i);
    }

    free(parent);
    free(key);
    free(mstSet);
}

/* Example:
Input:
Enter the number of vertices: 5
Enter the number of edges: 7
Enter the edges with weights (u v w format, 0-indexed):
0 1 2
0 3 6
1 3 8
1 2 3
1 4 5
2 4 7
3 4 9
Output:
Edges in the Minimum Spanning Tree:
0 - 1
1 - 2
0 - 3
1 - 4
*/