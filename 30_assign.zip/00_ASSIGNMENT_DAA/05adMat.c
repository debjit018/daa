#include <stdio.h>

void adMat(int r, int c, int mat1[r][c], int mat2[r][c], int res[r][c], int i, int j);

int main() {
    int r, c;
    printf("Enter number of rows and columns: ");
    scanf("%d %d", &r, &c);

    int mat1[r][c], mat2[r][c], res[r][c];

    printf("Enter elements of first matrix (%d elements):\n", r * c);
    for (int i = 0; i < r; i++) {
        for (int j = 0; j < c; j++) {
            scanf("%d", &mat1[i][j]);
        }
    }

    printf("Enter elements of second matrix (%d elements):\n", r * c);
    for (int i = 0; i < r; i++) {
        for (int j = 0; j < c; j++) {
            scanf("%d", &mat2[i][j]);
        }
    }

    adMat(r, c, mat1, mat2, res, 0, 0);

    printf("Resultant matrix after addition:\n");
    for (int i = 0; i < r; i++) {
        for (int j = 0; j < c; j++) {
            printf("%d ", res[i][j]);
        }
        printf("\n");
    }
    return 0;
}

void adMat(int r, int c, int mat1[r][c], int mat2[r][c], int res[r][c], int i, int j) {
    if (i >= r) {
        return;
    }
    if (j < c) {
        res[i][j] = mat1[i][j] + mat2[i][j];
        adMat(r, c, mat1, mat2, res, i, j + 1);
    } else {
        adMat(r, c, mat1, mat2, res, i + 1, 0);
    }
}

/* Example:
Input:
Enter number of rows and columns: 2 2
Enter elements of first matrix (4 elements):
1 2
3 4
Enter elements of second matrix (4 elements):
5 6
7 8
Output:
Resultant matrix after addition:
6 8
10 12
*/