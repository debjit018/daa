#include <stdio.h>
#include <stdlib.h>

struct Node {
    int data;
    struct Node* left;
    struct Node* right;
};

struct Node* createNode(int data);
struct Node* insertNode();
void inorder(struct Node* root);

int main() {
    printf("Enter binary tree nodes (-1 for no node):\n");
    struct Node* root = insertNode();

    printf("Inorder traversal: ");
    inorder(root);

    return 0;
}

struct Node* createNode(int data) {
    struct Node* newNode = (struct Node*)malloc(sizeof(struct Node));
    newNode->data = data;
    newNode->left = NULL;
    newNode->right = NULL;
    return newNode;
}

struct Node* insertNode() {
    int data;
    printf("Enter data: ");
    scanf("%d", &data);

    if (data == -1)
        return NULL;

    struct Node* node = createNode(data);
    printf("Enter left child of %d:\n", data);
    node->left = insertNode();
    printf("Enter right child of %d:\n", data);
    node->right = insertNode();

    return node;
}

void inorder(struct Node* root) {
    if (root == NULL)
        return;
    inorder(root->left);
    printf("%d ", root->data);
    inorder(root->right);
}

/* Example:
Input:
Enter binary tree nodes (-1 for no node):
Enter data: 1
Enter left child of 1:
Enter data: 2
Enter left child of 2:
Enter data: 4
Enter left child of 4:
Enter data: -1
Enter right child of 4:
Enter data: -1
Enter right child of 2:
Enter data: 5
Enter left child of 5:
Enter data: -1
Enter right child of 5:
Enter data: -1
Enter right child of 1:
Enter data: 3
Enter left child of 3:
Enter data: -1
Enter right child of 3:
Enter data: -1
Output:
Inorder traversal: 4 2 5 1 3
*/
