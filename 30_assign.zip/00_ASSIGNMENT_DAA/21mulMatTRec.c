#include <stdio.h>

void multiplyMatricesRec(int r1, int c1, int c2, int mat1[r1][c1], int mat2[c1][c2], int result[r1][c2], int i, int j, int k);

int main() {
    int r1, c1, r2, c2;
    printf("Enter rows and columns of first matrix: ");
    scanf("%d %d", &r1, &c1);
    printf("Enter rows and columns of second matrix: ");
    scanf("%d %d", &r2, &c2);

    if (c1 != r2) {
        printf("Matrix multiplication not possible.\n");
        return 0;
    }

    int mat1[r1][c1], mat2[r2][c2], result[r1][c2];

    printf("Enter elements of first matrix:\n");
    for (int i = 0; i < r1; i++)
        for (int j = 0; j < c1; j++)
            scanf("%d", &mat1[i][j]);

    printf("Enter elements of second matrix:\n");
    for (int i = 0; i < r2; i++)
        for (int j = 0; j < c2; j++)
            scanf("%d", &mat2[i][j]);

    for (int i = 0; i < r1; i++)
        for (int j = 0; j < c2; j++)
            result[i][j] = 0;

    multiplyMatricesRec(r1, c1, c2, mat1, mat2, result, 0, 0, 0);

    printf("Resultant matrix:\n");
    for (int i = 0; i < r1; i++) {
        for (int j = 0; j < c2; j++) {
            printf("%d ", result[i][j]);
        }
        printf("\n");
    }

    return 0;
}

void multiplyMatricesRec(int r1, int c1, int c2, int mat1[r1][c1], int mat2[c1][c2], int result[r1][c2], int i, int j, int k) {
    if (i >= r1)
        return;

    if (j < c2) {
        if (k < c1) {
            result[i][j] += mat1[i][k] * mat2[k][j];
            multiplyMatricesRec(r1, c1, c2, mat1, mat2, result, i, j, k + 1);
        } else {
            multiplyMatricesRec(r1, c1, c2, mat1, mat2, result, i, j + 1, 0);
        }
    } else {
        multiplyMatricesRec(r1, c1, c2, mat1, mat2, result, i + 1, 0, 0);
    }
}

/* Example:
Input:
Enter rows and columns of first matrix: 2 2
Enter rows and columns of second matrix: 2 2
Enter elements of first matrix:
1 2
3 4
Enter elements of second matrix:
5 6
7 8
Output:
Resultant matrix:
19 22
43 50
*/#include <stdio.h>

void multiplyMatricesRec(int r1, int c1, int c2, int mat1[r1][c1], int mat2[c1][c2], int result[r1][c2], int i, int j, int k);

int main() {
    int r1, c1, r2, c2;
    printf("Enter rows and columns of first matrix: ");
    scanf("%d %d", &r1, &c1);
    printf("Enter rows and columns of second matrix: ");
    scanf("%d %d", &r2, &c2);

    if (c1 != r2) {
        printf("Matrix multiplication not possible.\n");
        return 0;
    }

    int mat1[r1][c1], mat2[r2][c2], result[r1][c2];

    printf("Enter elements of first matrix:\n");
    for (int i = 0; i < r1; i++)
        for (int j = 0; j < c1; j++)
            scanf("%d", &mat1[i][j]);

    printf("Enter elements of second matrix:\n");
    for (int i = 0; i < r2; i++)
        for (int j = 0; j < c2; j++)
            scanf("%d", &mat2[i][j]);

    for (int i = 0; i < r1; i++)
        for (int j = 0; j < c2; j++)
            result[i][j] = 0;

    multiplyMatricesRec(r1, c1, c2, mat1, mat2, result, 0, 0, 0);

    printf("Resultant matrix:\n");
    for (int i = 0; i < r1; i++) {
        for (int j = 0; j < c2; j++) {
            printf("%d ", result[i][j]);
        }
        printf("\n");
    }

    return 0;
}

void multiplyMatricesRec(int r1, int c1, int c2, int mat1[r1][c1], int mat2[c1][c2], int result[r1][c2], int i, int j, int k) {
    if (i >= r1)
        return;

    if (j < c2) {
        if (k < c1) {
            result[i][j] += mat1[i][k] * mat2[k][j];
            multiplyMatricesRec(r1, c1, c2, mat1, mat2, result, i, j, k + 1);
        } else {
            multiplyMatricesRec(r1, c1, c2, mat1, mat2, result, i, j + 1, 0);
        }
    } else {
        multiplyMatricesRec(r1, c1, c2, mat1, mat2, result, i + 1, 0, 0);
    }
}

/* Example:
Input:
Enter rows and columns of first matrix: 2 2
Enter rows and columns of second matrix: 2 2
Enter elements of first matrix:
1 2
3 4
Enter elements of second matrix:
5 6
7 8
Output:
Resultant matrix:
19 22
43 50
*/