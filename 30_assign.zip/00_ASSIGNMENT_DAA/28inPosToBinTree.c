#include <stdio.h>
#include <stdlib.h>

struct Node {
    int data;
    struct Node* left;
    struct Node* right;
};

struct Node* createNode(int data);
struct Node* buildTree(int in[], int post[], int inStart, int inEnd, int* postIndex);
int search(int arr[], int start, int end, int value);
void inorder(struct Node* root);

int main() {
    int n;
    printf("Enter number of nodes: ");
    scanf("%d", &n);

    int in[n], post[n];
    printf("Enter Inorder traversal: ");
    for (int i = 0; i < n; i++) {
        scanf("%d", &in[i]);
    }

    printf("Enter Postorder traversal: ");
    for (int i = 0; i < n; i++) {
        scanf("%d", &post[i]);
    }

    int postIndex = n - 1;
    struct Node* root = buildTree(in, post, 0, n - 1, &postIndex);

    printf("Inorder traversal of the constructed tree: ");
    inorder(root);

    return 0;
}

struct Node* createNode(int data) {
    struct Node* newNode = (struct Node*)malloc(sizeof(struct Node));
    newNode->data = data;
    newNode->left = NULL;
    newNode->right = NULL;
    return newNode;
}

struct Node* buildTree(int in[], int post[], int inStart, int inEnd, int* postIndex) {
    if (inStart > inEnd)
        return NULL;

    struct Node* tNode = createNode(post[*postIndex]);
    (*postIndex)--;

    if (inStart == inEnd)
        return tNode;

    int inIndex = search(in, inStart, inEnd, tNode->data);

    tNode->right = buildTree(in, post, inIndex + 1, inEnd, postIndex);
    tNode->left = buildTree(in, post, inStart, inIndex - 1, postIndex);

    return tNode;
}

int search(int arr[], int start, int end, int value) {
    for (int i = start; i <= end; i++) {
        if (arr[i] == value)
            return i;
    }
    return -1;
}

void inorder(struct Node* root) {
    if (root == NULL)
        return;
    inorder(root->left);
    printf("%d ", root->data);
    inorder(root->right);
}

/* Example:
Input:
Enter number of nodes: 5
Enter Inorder traversal: 4 2 5 1 3
Enter Postorder traversal: 4 5 2 3 1
Output:
Inorder traversal of the constructed tree: 4 2 5 1 3
*/