#include <stdio.h>
#include <stdlib.h>

void dfs(int** graph, int* visited, int v, int start);

int main() {
    int v, e;
    printf("Enter the number of vertices: ");
    scanf("%d", &v);

    int** graph = (int**)malloc(v * sizeof(int*));
    for (int i = 0; i < v; i++) {
        graph[i] = (int*)calloc(v, sizeof(int));
    }

    printf("Enter the number of edges: ");
    scanf("%d", &e);

    printf("Enter the edges (u v format, 0-indexed):\n");
    for (int i = 0; i < e; i++) {
        int u, v;
        scanf("%d %d", &u, &v);
        graph[u][v] = 1;
        graph[v][u] = 1;
    }

    int* visited = (int*)calloc(v, sizeof(int));
    int start;
    printf("Enter the starting vertex: ");
    scanf("%d", &start);

    printf("DFS traversal: ");
    dfs(graph, visited, v, start);

    for (int i = 0; i < v; i++) {
        free(graph[i]);
    }
    free(graph);
    free(visited);

    return 0;
}

void dfs(int** graph, int* visited, int v, int start) {
    printf("%d ", start);
    visited[start] = 1;

    for (int i = 0; i < v; i++) {
        if (graph[start][i] && !visited[i]) {
            dfs(graph, visited, v, i);
        }
    }
}

/* Example:
Input:
Enter the number of vertices: 5
Enter the number of edges: 4
Enter the edges (u v format, 0-indexed):
0 1
0 2
1 3
1 4
Enter the starting vertex: 0
Output:
DFS traversal: 0 1 3 4 2
*/