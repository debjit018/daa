#include <stdio.h>

void recMulMat(int r1, int c1, int c2, int mat1[r1][c1], int mat2[c1][c2], int res[r1][c2], int i, int j, int k);

int main() {
    int r1, c1, r2, c2;
    printf("Enter rows and columns of first matrix: ");
    scanf("%d %d", &r1, &c1);
    printf("Enter rows and columns of second matrix: ");
    scanf("%d %d", &r2, &c2);

    if (c1 != r2) {
        printf("Matrix multiplication not possible (columns of first != rows of second).\n");
        return 1;
    }

    int mat1[r1][c1], mat2[r2][c2], res[r1][c2];

    printf("Enter elements of first matrix (%d elements):\n", r1 * c1);
    for (int i = 0; i < r1; i++) {
        for (int j = 0; j < c1; j++) {
            scanf("%d", &mat1[i][j]);
        }
    }

    printf("Enter elements of second matrix (%d elements):\n", r2 * c2);
    for (int i = 0; i < r2; i++) {
        for (int j = 0; j < c2; j++) {
            scanf("%d", &mat2[i][j]);
        }
    }

    for (int i = 0; i < r1; i++) {
        for (int j = 0; j < c2; j++) {
            res[i][j] = 0;
        }
    }

    recMulMat(r1, c1, c2, mat1, mat2, res, 0, 0, 0);

    printf("Resultant matrix after multiplication:\n");
    for (int i = 0; i < r1; i++) {
        for (int j = 0; j < c2; j++) {
            printf("%d ", res[i][j]);
        }
        printf("\n");
    }
    return 0;
}

void recMulMat(int r1, int c1, int c2, int mat1[r1][c1], int mat2[c1][c2], int res[r1][c2], int i, int j, int k) {
    if (i >= r1) return;

    if (j < c2) {
        if (k < c1) {
            res[i][j] += mat1[i][k] * mat2[k][j];
            recMulMat(r1, c1, c2, mat1, mat2, res, i, j, k + 1);
        } else {
            recMulMat(r1, c1, c2, mat1, mat2, res, i, j + 1, 0);
        }
    } else {
        recMulMat(r1, c1, c2, mat1, mat2, res, i + 1, 0, 0);
    }
}

/* Example:
Input:
Enter rows and columns of first matrix: 2 3
Enter rows and columns of second matrix: 3 2
Enter elements of first matrix (6 elements):
1 2 3
4 5 6
Enter elements of second matrix (6 elements):
7 8
9 10
11 12
Output:
Resultant matrix after multiplication:
58 64
139 154
*/