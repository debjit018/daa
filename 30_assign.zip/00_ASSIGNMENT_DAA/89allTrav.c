#include <stdio.h>
#include <stdlib.h>

typedef struct Node {
    int data;
    struct Node* left;
    struct Node* right;
} Node;

Node* createNode(int data);
Node* addNode(Node* root, int data);
void preOrder(Node* root);
void inOrder(Node* root);
void postOrder(Node* root);

int main() {
    Node* root = NULL;
    int choice, data;

    while (1) {
        printf("\nMenu:\n");
        printf("1. Add Node\n");
        printf("2. Pre-order Traversal\n");
        printf("3. In-order Traversal\n");
        printf("4. Post-order Traversal\n");
        printf("5. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                printf("Enter value to add: ");
                scanf("%d", &data);
                root = addNode(root, data);
                break;
            case 2:
                printf("Pre-order Traversal: ");
                preOrder(root);
                printf("\n");
                break;
            case 3:
                printf("In-order Traversal: ");
                inOrder(root);
                printf("\n");
                break;
            case 4:
                printf("Post-order Traversal: ");
                postOrder(root);
                printf("\n");
                break;
            case 5:
                exit(0);
            default:
                printf("Invalid choice!\n");
        }
    }

    return 0;
}

Node* createNode(int data) {
    Node* newNode = (Node*)calloc(1, sizeof(Node));
    newNode->data = data;
    newNode->left = newNode->right = NULL;
    return newNode;
}

Node* addNode(Node* root, int data) {
    if (root == NULL) {
        return createNode(data);
    }

    char dir;
    printf("Add %d as left (L) or right (R) child of %d: ", data, root->data);
    scanf(" %c", &dir);

    if (dir == 'L' || dir == 'l') {
        root->left = addNode(root->left, data);
    } else if (dir == 'R' || dir == 'r') {
        root->right = addNode(root->right, data);
    } else {
        printf("Invalid choice. Node not added.\n");
    }

    return root;
}

void preOrder(Node* root) {
    if (root == NULL) return;
    printf("%d ", root->data);
    preOrder(root->left);
    preOrder(root->right);
}

void inOrder(Node* root) {
    if (root == NULL) return;
    inOrder(root->left);
    printf("%d ", root->data);
    inOrder(root->right);
}

void postOrder(Node* root) {
    if (root == NULL) return;
    postOrder(root->left);
    postOrder(root->right);
    printf("%d ", root->data);
}

/* Example:
Menu:
1. Add Node
2. Pre-order Traversal
3. In-order Traversal
4. Post-order Traversal
5. Exit
Enter your choice: 1
Enter value to add: 10
Add 10 as left (L) or right (R) child of 10: L

Enter your choice: 1
Enter value to add: 20
Add 20 as left (L) or right (R) child of 10: R

Enter your choice: 2
Pre-order Traversal: 10 10 20
*/